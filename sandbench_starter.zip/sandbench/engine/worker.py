"""Worker: pulls jobs off the Upstash list and runs them in a sandbox.

Cross-language queue: Next.js LPUSHes JSON jobs, this worker BRPOPs them.
"""
import json
import os

import redis
from dotenv import load_dotenv

from sandbox.runner import run_code

load_dotenv()

JOBS_KEY = "sandbench:jobs"
RESULT_TTL = 3600  # seconds

r = redis.from_url(os.environ["UPSTASH_REDIS_URL"], decode_responses=True)


def classify(result: dict) -> str:
    """Placeholder verdict. Real malicious-vs-messy logic comes next session."""
    if result["timed_out"]:
        return "broken"
    return "clean" if result["exit_code"] == 0 else "broken"


def handle(job: dict) -> None:
    run_id = job["id"]
    r.set(f"sandbench:status:{run_id}", "running", ex=RESULT_TTL)

    result = run_code(job["code"])
    result["verdict"] = classify(result)

    r.set(f"sandbench:result:{run_id}", json.dumps(result), ex=RESULT_TTL)
    r.set(f"sandbench:status:{run_id}", "done", ex=RESULT_TTL)
    print(f"[done] {run_id} verdict={result['verdict']} exit={result['exit_code']}")


def main() -> None:
    print("worker up, waiting for jobs...")
    while True:
        # BRPOP blocks until a job arrives; (key, value) tuple returned
        _, raw = r.brpop(JOBS_KEY)
        try:
            handle(json.loads(raw))
        except Exception as e:  # never let one bad job kill the worker
            print(f"[error] {e}")


if __name__ == "__main__":
    main()
