"""Hardened, throwaway container runner.

Every run gets a FRESH container from a clean image and is ALWAYS destroyed.
Treat every submission as hostile. This is the §6 hardening checklist in code.
"""
import docker
import requests

client = docker.from_env()


def run_code(code: str, image: str = "python:3.11-slim", timeout: int = 10) -> dict:
    container = None
    try:
        container = client.containers.run(
            image,
            command=["python", "-c", code],
            detach=True,
            # --- hardening (§6) ---
            network_disabled=True,            # --network none
            read_only=True,                   # read-only root fs
            mem_limit="256m",                 # memory cap
            pids_limit=128,                   # block fork bombs
            nano_cpus=500_000_000,            # 0.5 CPU
            user="nobody",                    # non-root
            cap_drop=["ALL"],                 # drop all Linux capabilities
            security_opt=["no-new-privileges"],
            tmpfs={"/tmp": "size=64m,mode=1777"},  # small writable scratch only
        )
        timed_out = False
        try:
            result = container.wait(timeout=timeout)
            exit_code = result.get("StatusCode", -1)
        except requests.exceptions.ReadTimeout:
            container.kill()
            exit_code = -1
            timed_out = True

        logs = container.logs().decode("utf-8", errors="replace")
        return {"exit_code": exit_code, "logs": logs, "timed_out": timed_out}
    finally:
        if container is not None:
            try:
                container.remove(force=True)   # always destroy
            except Exception:
                pass
