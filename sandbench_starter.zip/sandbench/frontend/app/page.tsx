"use client";
import { useState, useRef } from "react";

export default function Home() {
  const [code, setCode] = useState('print("hello from the sandbox")');
  const [status, setStatus] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const poll = useRef<ReturnType<typeof setInterval> | null>(null);

  async function submit() {
    setResult(null);
    setStatus("submitting");
    const res = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });
    const { id } = await res.json();
    if (poll.current) clearInterval(poll.current);
    poll.current = setInterval(async () => {
      const r = await fetch(`/api/runs/${id}`);
      const data = await r.json();
      setStatus(data.status);
      if (data.status === "done") {
        setResult(data.result);
        if (poll.current) clearInterval(poll.current);
      }
    }, 1500);
  }

  return (
    <main style={{ maxWidth: 720, margin: "40px auto", padding: "0 16px" }}>
      <h1>SandBench</h1>
      <p>Submit Python code → it runs in a hardened throwaway container.</p>
      <textarea
        value={code}
        onChange={(e) => setCode(e.target.value)}
        rows={8}
        style={{ width: "100%", fontFamily: "monospace", padding: 12 }}
      />
      <button onClick={submit} style={{ marginTop: 12, padding: "8px 20px" }}>
        Run
      </button>
      {status && <p>Status: <b>{status}</b></p>}
      {result && (
        <div style={{ marginTop: 16 }}>
          <p>Verdict: <b>{result.verdict}</b> · exit {result.exit_code}
            {result.timed_out ? " · TIMED OUT" : ""}</p>
          <pre style={{ background: "#111", color: "#0f0", padding: 16, overflow: "auto" }}>
            {result.logs || "(no output)"}
          </pre>
        </div>
      )}
    </main>
  );
}
