import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { redis } from "@/lib/redis";

export async function POST(req: Request) {
  const { code } = await req.json();
  if (typeof code !== "string" || code.length === 0) {
    return NextResponse.json({ error: "code required" }, { status: 400 });
  }
  const id = randomUUID();
  await redis.set(`sandbench:status:${id}`, "queued", { ex: 3600 });
  // Language-agnostic queue: the Python worker BRPOPs this list.
  await redis.lpush("sandbench:jobs", JSON.stringify({ id, code }));
  return NextResponse.json({ id });
}
