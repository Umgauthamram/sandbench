import { NextResponse } from "next/server";
import { redis } from "@/lib/redis";

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const { id } = params;
  const status = await redis.get(`sandbench:status:${id}`);
  // @upstash/redis auto-parses JSON strings, so result comes back as an object.
  const result = await redis.get(`sandbench:result:${id}`);
  return NextResponse.json({ id, status, result });
}
